# Blog Writing Kit V1

짧은 생각 하나를 다음 결과로 만드는 개인 운영용 최소 워크플로다.

- 짧은 관찰형 블로그 글
- 한 장의 미니멀 삽화
- 발행 가능한 Markdown

현재 버전은 별도의 Agent나 Skill을 전제로 하지 않는다.

## 핵심 파일

- `BLOG_PLAYBOOK.md`: **유일한 텍스트 기준**. 글쓰기/편집/삽화 규칙, 작업 흐름, 승인된 Golden Example을 모두 포함한다.
- `references/CHARACTER_REFERENCE.png`: 반복해서 사용하는 사람 캐릭터의 시각 기준.

새 채팅에서 실제로 필요한 것은 위 두 파일뿐이다.

## 새 ChatGPT 채팅에서

1. `BLOG_PLAYBOOK.md`를 첨부한다.
2. 삽화를 만들 예정이면 `references/CHARACTER_REFERENCE.png`도 첨부한다.
3. 다음처럼 시작한다.

```text
이 Playbook을 전체 기준으로 사용해줘.
Source: [내 짧은 생각이나 질문]
```

Playbook에 정의된 기본 흐름은 다음과 같다.

```text
Source
-> 글 초안 + 삽화 장면 제안
-> 사람 승인/수정
-> 삽화 생성
-> 사람 승인
-> 발행용 Markdown
```

## Golden Example 관리

승인된 예제는 별도 파일로 흩어놓지 않고 `BLOG_PLAYBOOK.md` 하단의 `Approved Golden Examples`에 추가한다.

최소 형식은 다음 두 항목이다.

- Source
- Final

Illustration이나 Note는 특정 글에서 꼭 보존할 이유가 있을 때만 선택적으로 추가한다.

## API

`api/blog_cli.py`도 `BLOG_PLAYBOOK.md` 하나를 읽도록 맞춰져 있다.
자세한 내용은 `API_USAGE.md`를 참고한다.

## 기타 폴더

- `drafts/`: 작업 중인 글
- `posts/`: 승인된 발행용 Markdown
- `assets/`: 생성된 삽화
- `templates/`: 사람이 아이디어를 기록할 때 쓸 선택적 템플릿

`API_USAGE.md`, `PUBLISHING.md`는 운영 설명 문서일 뿐 모델에게 매번 제공할 필요는 없다.
