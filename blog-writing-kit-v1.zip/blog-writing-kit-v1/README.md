# Blog Writing Kit V1

A small, portable workflow for turning one short idea into:

- a reflective blog post
- one minimal illustration
- publication-ready Markdown

This version intentionally does not require an Agent or Skill.

## Files

- BLOG_GUIDE.md: single source of truth for writing, editing, and illustration style
- golden/: approved Source -> Final examples
- CHAT_START.md: bootstrap prompt for a fresh ChatGPT chat
- templates/IDEA.md: minimal idea input
- api/blog_cli.py: optional API workflow
- API_USAGE.md: API instructions
- PUBLISHING.md: publishing boundary and handoff
- drafts/: work in progress
- posts/: approved publication Markdown
- assets/: generated illustrations

## Operating principle

Start with a result, not infrastructure.

The human provides a short Source. The model creates a draft. The human approves or edits it. Only then is the illustration generated. Publishing remains manual until the target CMS is known.

## Golden examples

A golden example only needs:

- Source
- Final

Do not repeat global illustration or writing rules inside each example.

## New ChatGPT chat

Upload BLOG_GUIDE.md and the files in golden/, then paste CHAT_START.md and append your Source.

## API

See API_USAGE.md.
