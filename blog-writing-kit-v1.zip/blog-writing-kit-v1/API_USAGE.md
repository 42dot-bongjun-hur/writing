# API usage

This CLI intentionally keeps a human approval step.

1. Install:

   pip install -U -r api/requirements.txt

2. Export environment variables from api/.env.example.

3. Create a draft:

   python api/blog_cli.py draft --idea "your idea"

   The command prints the created draft paths, for example:

   drafts/20260918-123000.md
   drafts/20260918-123000.json

4. Review and edit the Markdown draft if needed.

5. When the text is approved, generate the illustration and publication package:

   python api/blog_cli.py finalize drafts/20260918-123000.json

The finalize command writes matching files under:

- posts/
- assets/

Publishing to a CMS is deliberately not automated yet. First complete a few posts manually, then add one adapter for the CMS you actually use.


## Character reference

`references/CHARACTER_REFERENCE.png` is the approved visual identity for the recurring human character.

The current CLI keeps the image step intentionally simple and relies on the text rules in `BLOG_PLAYBOOK.md`; it does not yet pass the PNG as an image input. For the first few posts, use the reference image directly in an image-capable chat when visual consistency matters most. Add reference-image API wiring only after the manual publishing loop has been proven useful.
