import argparse
import base64
import json
import os
from pathlib import Path
from datetime import datetime

from openai import OpenAI
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[1]
DRAFTS = ROOT / "drafts"
POSTS = ROOT / "posts"
ASSETS = ROOT / "assets"


class BlogDraft(BaseModel):
    title: str
    paragraphs: list[str]
    illustration_scene: str


def load_context() -> str:
    guide = (ROOT / "BLOG_PLAYBOOK.md").read_text(encoding="utf-8")
    examples = []
    for path in sorted((ROOT / "golden").glob("*.md")):
        examples.append(path.read_text(encoding="utf-8"))
    return guide + "\n\n# Approved Golden Examples\n\n" + "\n\n---\n\n".join(examples)


def get_client() -> OpenAI:
    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is not set")
    return OpenAI()


def text_model() -> str:
    value = os.getenv("OPENAI_TEXT_MODEL")
    if not value:
        raise SystemExit("OPENAI_TEXT_MODEL is not set")
    return value


def image_model() -> str:
    value = os.getenv("OPENAI_IMAGE_MODEL")
    if not value:
        raise SystemExit("OPENAI_IMAGE_MODEL is not set")
    return value


def render_markdown(draft: BlogDraft) -> str:
    blocks = [f"# {draft.title}", ""]
    for paragraph in draft.paragraphs:
        blocks.append(f"- {paragraph.strip()}")
        blocks.append("")
    blocks.append("<!--")
    blocks.append(f"ILLUSTRATION_SCENE: {draft.illustration_scene.strip()}")
    blocks.append("-->")
    return "\n".join(blocks).rstrip() + "\n"


def draft_command(idea: str) -> None:
    client = get_client()
    context = load_context()
    response = client.responses.parse(
        model=text_model(),
        input=[
            {
                "role": "system",
                "content": context,
            },
            {
                "role": "user",
                "content": (
                    "Create a draft from the Source below. Write in the same language as the Source. "
                    "Return a title, 3-8 paragraph blocks, and one minimal illustration scene. "
                    "Do not turn a reflective question into advice unless the Source calls for it.\n\n"
                    f"Source:\n{idea}"
                ),
            },
        ],
        text_format=BlogDraft,
    )
    draft = response.output_parsed
    if draft is None:
        raise SystemExit("No parsed draft was returned")

    DRAFTS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    json_path = DRAFTS / f"{stamp}.json"
    md_path = DRAFTS / f"{stamp}.md"
    json_path.write_text(
        json.dumps(draft.model_dump(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    markdown = render_markdown(draft)
    md_path.write_text(markdown, encoding="utf-8")
    print(markdown)
    print(f"Saved: {md_path.relative_to(ROOT)} and {json_path.relative_to(ROOT)}")
    print("Review the text. Finalize only after you approve it.")


def generate_image(client: OpenAI, scene: str, context: str) -> bytes:
    prompt = (
        "Generate exactly one blog illustration for the scene below. "
        "Apply the illustration rules from the system guide. "
        "Keep all drawn content within 40 percent of the canvas. "
        "Use large negative space and a loose one-line hand-drawn feeling. "
        "The background must be pure white or transparent, never black or dark. "
        "Do not put any text, labels, speech bubbles, title, or typography in the image. "
        "Do not try to depict every idea in the article.\n\n"
        f"Scene:\n{scene}"
    )
    response = client.responses.create(
        model=text_model(),
        input=[
            {"role": "system", "content": context},
            {"role": "user", "content": prompt},
        ],
        tools=[
            {
                "type": "image_generation",
                "model": image_model(),
                "action": "generate",
            }
        ],
        tool_choice={"type": "image_generation"},
    )
    for item in response.output:
        if getattr(item, "type", None) == "image_generation_call":
            result = getattr(item, "result", None)
            if result:
                return base64.b64decode(result)
    raise SystemExit("No image was returned")


def extract_title(markdown: str) -> str:
    for line in markdown.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return "Untitled"


def finalize_command(json_path: Path) -> None:
    client = get_client()
    context = load_context()
    data = json.loads(json_path.read_text(encoding="utf-8"))
    draft = BlogDraft.model_validate(data)

    md_path = json_path.with_suffix(".md")
    if not md_path.exists():
        raise SystemExit(f"Matching Markdown draft not found: {md_path}")
    approved_md = md_path.read_text(encoding="utf-8")

    ASSETS.mkdir(parents=True, exist_ok=True)
    POSTS.mkdir(parents=True, exist_ok=True)
    image_bytes = generate_image(client, draft.illustration_scene, context)
    stem = json_path.stem
    image_path = ASSETS / f"{stem}.png"
    image_path.write_bytes(image_bytes)

    title = extract_title(approved_md)
    body = []
    in_comment = False
    for line in approved_md.splitlines():
        if line.strip() == "<!--":
            in_comment = True
            continue
        if line.strip() == "-->":
            in_comment = False
            continue
        if not in_comment:
            body.append(line)
    clean_md = "\n".join(body).rstrip()

    post = (
        "---\n"
        f'title: "{title.replace(chr(34), chr(39))}"\n'
        f'image: "/assets/{stem}.png"\n'
        "---\n\n"
        f"{clean_md}\n\n"
        f"![illustration](/assets/{stem}.png)\n"
    )
    post_path = POSTS / f"{stem}.md"
    post_path.write_text(post, encoding="utf-8")

    print(f"Saved image: {image_path.relative_to(ROOT)}")
    print(f"Saved post:  {post_path.relative_to(ROOT)}")
    print("This is the publication package. Publish it manually to your CMS for now.")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    draft_parser = sub.add_parser("draft")
    draft_parser.add_argument("--idea", required=True)

    final_parser = sub.add_parser("finalize")
    final_parser.add_argument("json_path", type=Path)

    args = parser.parse_args()
    if args.command == "draft":
        draft_command(args.idea)
    elif args.command == "finalize":
        finalize_command(args.json_path)


if __name__ == "__main__":
    main()
