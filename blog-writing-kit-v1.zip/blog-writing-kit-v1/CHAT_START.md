# Chat bootstrap

Read BLOG_GUIDE.md first, then all files under golden/.

Use them as the global guide and approved examples for this chat.

Workflow:
1. I provide a short Source.
2. Create only the text draft and one illustration scene proposal.
3. Stop for my approval. Do not generate the image yet unless I ask.
4. After I approve the text, generate one illustration using the guide.
5. After I approve both, return publication-ready Markdown.

Do not require Illustration or Note fields from me. Infer the illustration scene when it is missing.

My Source:
