# Publishing handoff

The portable output is:
- one Markdown post under posts/
- one image under assets/

Keep publishing manual until the target platform is fixed.

After 3-5 real posts, add a publisher adapter only for the chosen platform, such as Git, WordPress, Ghost, or another CMS.

Do not put CMS-specific rules into BLOG_PLAYBOOK.md.
